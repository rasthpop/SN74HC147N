/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>



int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    UART_Start();
    
    char buffer[64];
    
    UART_UartPutString("Testing SN74HC147H\r\n");


    for(uint8_t exp = 0; exp < 10; ++exp){
        uint16_t input = 1 << exp;

        Pin_1_Write(!(input & 0x01));
        Pin_2_Write(!((input >> 1) & 0x01));
        Pin_3_Write(!((input >> 2) & 0x01));
        Pin_4_Write(!((input >> 3) & 0x01));
        Pin_5_Write(!((input >> 4) & 0x01));
        Pin_6_Write(!((input >> 5) & 0x01));
        Pin_7_Write(!((input >> 6) & 0x01));
        Pin_8_Write(!((input >> 7) & 0x01));
        Pin_9_Write(!((input >> 8) & 0x01));
        
        uint8_t ra = A_Read();
        uint8_t rb = B_Read();
        uint8_t rc = C_Read();
        uint8_t rd = D_Read();
        
        sprintf(buffer, "For L on input index %u Outputs: %u%u%u%u \r\n", exp + 1, rd, rc, rb, ra);
        UART_UartPutString(buffer);
        
        CyDelay(200);
    }
    
    UART_UartPutString("Testing SN74HC147H for priority bits\r\n");
    
    for(uint8_t input = 0; input < 8; ++input){

        Pin_1_Write(!(input & 0x01));
        Pin_2_Write(!((input >> 1) & 0x01));
        Pin_3_Write(!((input >> 2) & 0x01));
        Pin_4_Write(!((input >> 3) & 0x01));
        Pin_5_Write(!((input >> 4) & 0x01));
        Pin_6_Write(!((input >> 5) & 0x01));
        Pin_7_Write(!((input >> 6) & 0x01));
        Pin_8_Write(!((input >> 7) & 0x01));
        Pin_9_Write(!((input >> 8) & 0x01));
        
        uint8_t ra = A_Read();
        uint8_t rb = B_Read();
        uint8_t rc = C_Read();
        uint8_t rd = D_Read();
        
        sprintf(buffer, "For input data %u, MSB: %u%u%u%u \r\n", input, rd, rc, rb, ra);
        UART_UartPutString(buffer);
        
        CyDelay(200);
    }
    
    
    for(;;)
    {
     
    }
}

/* [] END OF FILE */
